import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Base64;

public class Client {
    public Client() throws Exception{
        Socket socket = new Socket("localhost", 2024);

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));

        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()),true);


        System.out.println(in.readLine());

        File file = new File("KEY.key");
        long size = file.length();
        FileInputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[(int) size];
        fis.read(buffer);
        fis.close();

        SecretKeySpec key = new SecretKeySpec(buffer, "AES");

        while (true) {
            System.out.println("Unesite poruku: ");
            String tekst = tin.readLine();

            String enTekst = encyptAES(tekst, key);

            String hash = hesujMD5(tekst);

            out.println(hash + ":" + enTekst);

            String poruka = in.readLine();

            if (poruka.equals("LOSAPORUKA")) {
                System.out.println("Komunikacija prekinuta - narusen integritet");
                break;
            }

            String[] podelaPoruke = poruka.split(":");
            String serverHash = podelaPoruke[0]; // prvi deo poruke je hash
            String serverAES = podelaPoruke[1]; // drugi deo poruke je Cipher tekst
            String serverPoruka = decryptAES(serverAES, key);

            System.out.println("Server poruka: " + serverPoruka);
            System.out.println("Server hash: " + serverHash);
            System.out.println("Server AES: " + serverAES);


            String clientHash = hesujMD5(serverPoruka);

            if (clientHash.equals(serverHash)){
                System.out.println("Intergrite je potvrdjen");
            }else{
                System.out.println("Integritet je narusen");
                out.println("LOSAPORUKA");
                break;
            }
        }

        socket.close();

    }

    private String decryptAES(String sifrovan, SecretKey key) throws Exception{

        Base64.Decoder decoder = Base64.getDecoder();
        byte[] sifrovanBytes = decoder.decode(sifrovan);


        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] dekriptovanBytes = cipher.doFinal(sifrovanBytes);

        return new String(dekriptovanBytes);
    }

    private String encyptAES(String tekst, SecretKey key) throws Exception{

        byte[] tekstBytes = tekst.getBytes();

        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] enkripovanBytes = cipher.doFinal(tekstBytes);

        Base64.Encoder encoder = Base64.getEncoder();
        String enkriptovan = encoder.encodeToString(enkripovanBytes);

        return enkriptovan;
    }

    public String hesujMD5(String tekst) throws Exception{

        MessageDigest messageDigest = MessageDigest.getInstance("MD5");

        byte[] tekstByte = tekst.getBytes();

        byte[] hashByte = messageDigest.digest(tekstByte);

        String hash = bytesToHex(hashByte);

        return hash;
    }

    public static String bytesToHex(byte[] data) {
        StringBuffer results = new StringBuffer();
        for (byte byt : data)
            results.append(Integer.toString((byt & 0xff) + 0x100, 16).substring(1));
        return results.toString();
    }

    public static void main(String[] args) throws Exception {
        new Client();
    }

}