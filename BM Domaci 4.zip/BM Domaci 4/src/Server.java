import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Base64;

public class Server {

    public Server() throws Exception{
        ServerSocket serverSocket = new ServerSocket(2024);
        Socket socket = serverSocket.accept();

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

        SecretKey key = generiseAESkljuc();

        FileOutputStream fos = new FileOutputStream("KEY.key");
        fos.write(key.getEncoded());
        fos.flush();
        fos.close();

        out.println("Dobodoslica :D");

        while (true) {
            String poruka = in.readLine();



            if (poruka.equals("LOSAPORUKA")) {
                System.out.println("Komunikacija prekinuta - narusen integritet");
                break;
            }
            System.out.println("Server vidi kao: " + poruka);

            String[] podelaPoruke = poruka.split(":");
            String clientHash = podelaPoruke[0];
            String clientAES = podelaPoruke[1];
            String clientTekst = decryptAES(clientAES, key);


            System.out.println("Client tekst: " + clientTekst);
            System.out.println("Client hash: " + clientHash);
            System.out.println("Client AES: " + clientAES);

            String serverHash = hesujMD5(clientTekst);

            if (clientHash.equals(serverHash)) {
                System.out.println("Integritet potvrdjen");

                System.out.println("Unesite poruku: ");
                String serverPoruka = tin.readLine();

                String serverAES = encyptAES(serverPoruka, key);


                serverHash = hesujMD5(serverPoruka);
                out.println(serverHash + ":" + serverAES);
            } else {
                System.out.println("Narusen integritet");
                System.out.println("Prekida se komunikacija");
                out.println("LOSAPORUKA");
                break;
            }
        }

        socket.close();

    }

    private SecretKey generiseAESkljuc() throws Exception{

        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128);
        SecretKey kljuc = keyGenerator.generateKey();

        return kljuc;
    }

    private String decryptAES(String sifrovan, SecretKey key) throws Exception{
        // Korak 1
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] sifrovanBytes = decoder.decode(sifrovan);

        // Korak 2
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] dekriptovanBytes = cipher.doFinal(sifrovanBytes);

        // Korak 3
        return new String(dekriptovanBytes);
    }

    private String encyptAES(String tekst, SecretKey key) throws Exception{

        byte[] tekstBytes = tekst.getBytes();

        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] enkripovanBytes = cipher.doFinal(tekstBytes);

        Base64.Encoder encoder = Base64.getEncoder();
        String enkriptovan = encoder.encodeToString(enkripovanBytes);

        return enkriptovan;
    }

    public String hesujMD5(String tekst) throws Exception{

        MessageDigest messageDigest = MessageDigest.getInstance("MD5");

        byte[] tekstByte = tekst.getBytes();

        byte[] hashByte = messageDigest.digest(tekstByte);

        String hash = bytesToHex(hashByte);

        return hash;
    }

    public static String bytesToHex(byte[] data) {
        StringBuffer results = new StringBuffer();
        for (byte byt : data)
            results.append(Integer.toString((byt & 0xff) + 0x100, 16).substring(1));
        return results.toString();
    }

    public static void main(String[] args) throws Exception{
        new Server();
    }
}